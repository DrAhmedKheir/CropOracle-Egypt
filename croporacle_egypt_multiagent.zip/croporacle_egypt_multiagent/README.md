# CropOracle Egypt

CropOracle Egypt is a WhatsApp-based wheat advisory prototype for Egypt. A farmer sends one natural-language message, the backend extracts the scenario, prepares APSIM Next Generation simulations, runs sowing/irrigation/fertilizer/climate comparisons, and returns a simple advisory message through WhatsApp.

## Core workflow

1. Farmer sends WhatsApp message.
2. Flask receives the webhook.
3. Scenario planner extracts location, crop, sowing dates, climate change assumptions, irrigation, fertilizer, and farm area.
4. APSIM runner copies a wheat APSIM template, modifies sowing date/weather/management parameters, and runs APSIM Next Gen.
5. Result parser reads APSIM output SQLite/CSV.
6. Advisory generator sends a concise answer back to WhatsApp.

## Project structure

```text
croporacle_egypt/
  app/
    main.py                  # Flask app entry point
    config.py                # Environment/config loading
    services/
      scenario_planner.py    # LLM-based and rule-based scenario extraction
      apsim_runner.py        # APSIM file preparation and execution
      weather_engine.py      # NASA POWER/local weather placeholders
      results_parser.py      # APSIM output parser
      advisory_generator.py  # Farmer-friendly advisory text
      whatsapp_client.py     # WhatsApp Cloud API sender
    templates/
      planner_prompt.txt     # Prompt used by LLM planner
      reply_template_ar.txt  # Arabic WhatsApp answer template
      reply_template_en.txt  # English WhatsApp answer template
  apsim_templates/
    egypt_wheat_template.apsimx
    soil_profiles_egypt.json
    cultivar_wheat_egypt.json
  scripts/
    run_local_demo.py
  docs/
    egypt_wheat_workflow.md
    deployment_notes.md
  outputs/
  requirements.txt
  .env.example
```

## Quick start

```bash
cd croporacle_egypt
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python scripts/run_local_demo.py
```

## Flask server

```bash
python -m app.main
```

## Required external tools

- APSIM Next Generation installed locally or on a server.
- WhatsApp Cloud API credentials or Twilio WhatsApp credentials.
- Optional: OpenAI/Anthropic API key for natural-language scenario extraction.

## Important notes

This is a strong prototype skeleton. Before farmer deployment, APSIM wheat cultivar, soil, irrigation, and nitrogen parameters must be calibrated for Egyptian conditions and validated against field data.

---

## Multi-Agent AI Upgrade

This package now includes a multi-agent architecture under `app/agents/`.

### Main agents

- `IntakeAgent`: understands the farmer message and extracts the scenario.
- `WeatherAgent`: selects weather source/coordinates for Egypt.
- `SoilAgent`: selects an Egyptian soil profile.
- `SimulationAgent`: prepares and runs APSIM scenario combinations.
- `ValidationAgent`: checks scenario reliability and warnings.
- `AdvisoryAgent`: writes a farmer-ready WhatsApp response.
- `CropOracleMultiAgentCoordinator`: runs all agents in sequence.

### Run the multi-agent demo

```bash
python scripts/run_multiagent_demo.py
```

### Test through Flask

```bash
curl -X POST http://127.0.0.1:5000/simulate-agent \
  -H "Content-Type: application/json" \
  -d '{"phone":"demo", "message":"I am in Kafr El-Sheikh. Rainfall drops 20% and temperature increases 2 C. Which sowing date is best for wheat?"}'
```

### Optional LangGraph version

The file `app/agents/langgraph_workflow.py` contains a LangGraph-compatible version. Use it when you want advanced routing, memory, retries, human review, or parallel scenario execution.
